#include <SDL2/SDL.h>
#include <stdio.h>

// Screen dimension constants
const int SCREEN_WIDTH = 800;
const int SCREEN_HEIGHT = 600;

// Ball structure
typedef struct {
    float x, y;
    float velX, velY;
    int size;
} Ball;

// Paddle structure
typedef struct {
    float x, y;
    float velY;
    int width, height;
} Paddle;

// Initialize SDL
int init(SDL_Window **window, SDL_Renderer **renderer) {
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("SDL could not initialize! SDL_Error: %s\n", SDL_GetError());
        return 0;
    }

    *window = SDL_CreateWindow("Pong", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
    if (!*window) {
        printf("Window could not be created! SDL_Error: %s\n", SDL_GetError());
        return 0;
    }

    *renderer = SDL_CreateRenderer(*window, -1, SDL_RENDERER_ACCELERATED);
    if (!*renderer) {
        printf("Renderer could not be created! SDL_Error: %s\n", SDL_GetError());
        return 0;
    }

    return 1;
}

// Handle paddle movement
void handleInput(Paddle *paddle1, Paddle *paddle2, int *quit) {
    SDL_Event e;
    const Uint8 *currentKeyStates = SDL_GetKeyboardState(NULL);

    while (SDL_PollEvent(&e) != 0) {
        if (e.type == SDL_QUIT) {
            *quit = 1;
        }
    }

    paddle1->velY = 0;
    paddle2->velY = 0;

    if (currentKeyStates[SDL_SCANCODE_W]) {
        paddle1->velY = -5;
    } else if (currentKeyStates[SDL_SCANCODE_S]) {
        paddle1->velY = 5;
    }

    if (currentKeyStates[SDL_SCANCODE_UP]) {
        paddle2->velY = -5;
    } else if (currentKeyStates[SDL_SCANCODE_DOWN]) {
        paddle2->velY = 5;
    }
}

// Move paddles and ball
void move(Paddle *paddle, Ball *ball) {
    paddle->y += paddle->velY;

    if (paddle->y < 0) {
        paddle->y = 0;
    } else if (paddle->y > SCREEN_HEIGHT - paddle->height) {
        paddle->y = SCREEN_HEIGHT - paddle->height;
    }

    ball->x += ball->velX;
    ball->y += ball->velY;

    if (ball->y < 0 || ball->y > SCREEN_HEIGHT - ball->size) {
        ball->velY = -ball->velY;
    }
}

// Check for collision and update ball direction
void checkCollision(Paddle *paddle1, Paddle *paddle2, Ball *ball) {
    if ((ball->x <= paddle1->x + paddle1->width && ball->x >= paddle1->x && ball->y >= paddle1->y && ball->y <= paddle1->y + paddle1->height) ||
        (ball->x + ball->size >= paddle2->x && ball->x + ball->size <= paddle2->x + paddle2->width && ball->y >= paddle2->y && ball->y <= paddle2->y + paddle2->height)) {
        ball->velX = -ball->velX;
    }
}

// Render the paddles and ball
void render(SDL_Renderer *renderer, Paddle *paddle1, Paddle *paddle2, Ball *ball) {
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderClear(renderer);

    SDL_Rect fillRect1 = { (int)paddle1->x, (int)paddle1->y, paddle1->width, paddle1->height };
    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
    SDL_RenderFillRect(renderer, &fillRect1);

    SDL_Rect fillRect2 = { (int)paddle2->x, (int)paddle2->y, paddle2->width, paddle2->height };
    SDL_RenderFillRect(renderer, &fillRect2);

    SDL_Rect ballRect = { (int)ball->x, (int)ball->y, ball->size, ball->size };
    SDL_RenderFillRect(renderer, &ballRect);

    SDL_RenderPresent(renderer);
}

int main(int argc, char* args[]) {
    SDL_Window *window = NULL;
    SDL_Renderer *renderer = NULL;

    if (!init(&window, &renderer)) {
        printf("Failed to initialize!\n");
        return 1;
    }

    Paddle paddle1 = { 30, (SCREEN_HEIGHT / 2) - 60, 0, 20, 120 };
    Paddle paddle2 = { SCREEN_WIDTH - 50, (SCREEN_HEIGHT / 2) - 60, 0, 20, 120 };
    Ball ball = { SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2, -4, -4, 15 };

    int quit = 0;

    while (!quit) {
        handleInput(&paddle1, &paddle2, &quit);
        move(&paddle1, &ball);
        move(&paddle2, &ball);
        checkCollision(&paddle1, &paddle2, &ball);
        render(renderer, &paddle1, &paddle2, &ball);
        SDL_Delay(16);
    }

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}
